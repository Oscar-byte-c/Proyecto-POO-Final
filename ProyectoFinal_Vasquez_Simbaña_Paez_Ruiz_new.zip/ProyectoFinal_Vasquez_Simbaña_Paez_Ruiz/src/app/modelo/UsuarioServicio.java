    package app.modelo;

    import java.io.BufferedReader;
    import java.io.FileReader;
    import java.io.IOException;
    import java.util.HashMap;

    public class UsuarioServicio {
        private static class DatosUsuario {
            String clave;
            String rol;
            public DatosUsuario(String clave, String rol) {
                this.clave = clave;
                this.rol = rol;
            }
        }

        private HashMap<String, DatosUsuario> usuarios = new HashMap<>();

        public UsuarioServicio() {
            cargarUsuariosDesdeArchivo();
        }

        private void cargarUsuariosDesdeArchivo() {
            try (BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Oscar\\Downloads\\ProyectoFinal_Vasquez_Simbaña_Paez_Ruiz\\src\\app\\modelo\\users.txt"))) {
                String linea;
                while ((linea = br.readLine()) != null) {
                    String[] partes = linea.split(";");
                    if (partes.length == 3) {
                        String usuario = partes[0].trim();
                        String clave = partes[1].trim();
                        String rol = partes[2].trim().toLowerCase();
                        usuarios.put(usuario, new DatosUsuario(clave, rol));
                    }
                }
            } catch (IOException e) {
                System.out.println("Error al leer el archivo de usuarios: " + e.getMessage());
            }
        }

        public boolean validar(String usuario, String contrasena, String rol) {
            try (BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\Oscar\\Downloads\\ProyectoFinal_Vasquez_Simbaña_Paez_Ruiz\\src\\app\\modelo\\users.txt"))) {
                String linea;
                while ((linea = reader.readLine()) != null) {
                    String[] partes = linea.split(";");
                    if (partes.length == 3) {
                        String u = partes[0];
                        String p = partes[1];
                        String r = partes[2];
                        if (u.equals(usuario) && p.equals(contrasena) && r.equalsIgnoreCase(rol)) {
                            return true;
                        }
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return false;
        }


        public String obtenerRol(String usuario) {
            if (!usuarios.containsKey(usuario)) return "invitado";
            return usuarios.get(usuario).rol;
        }
    }


