package app.vista.proyectoPoo;

//import taller.taller;

import app.controlador.Servicio;
import app.controlador.Usuario;
import app.modelo.Producto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Catalogocliente extends JFrame {
    private JTable tableProduc;
    private JPanel catalogocliente;
    private JButton salirButton;
    private JButton mostrarButton;
    private JButton añadirButton;
    private JButton eliminarButton;
    private DefaultTableModel model;
    private JLabel lblBienvenida;
    private JTextField textBuscar;
    private JButton buscarButton;
    private JFrame frame;

    private Object[] columns = {"ID", "Codigo", "Producto", "Precio"};
    private Object[] row = new Object[4];
    private Servicio servicio = new Servicio();
    private Map<Integer, Producto> mapa = null;
    private String clave;


    private List<Producto> selectedProducts = new ArrayList<>();

    public void obtenerRegistroTabla() {
        model = new DefaultTableModel() {
            private static final long serialVersionUID = 1L;
            @Override
            public boolean isCellEditable(int filas, int columnas) {
                return false;
            }
        };
        model.setColumnIdentifiers(columns);
        while (model.getRowCount() > 0) {
            model.removeRow(0);
        }
        mapa = servicio.seleccionarTodo();

        for (Map.Entry<Integer, Producto> entry : mapa.entrySet()) {
            row[0] = entry.getKey();
            row[1] = entry.getValue().getCodigo();
            row[2] = entry.getValue().getNombre();
            row[3] = String.format("%.2f", entry.getValue().getPrecio());
            model.addRow(row);
        }
        tableProduc.setModel(model);
    }

    public Catalogocliente() {
        setTitle("Catalogosclientes");
        setSize(700, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(catalogocliente);
        lblBienvenida.setText("Bienvenido, " + Usuario.getUsuario() + " (" + Usuario.getRol() + ")");
        String rol = Usuario.getRol();
        System.out.println("ROL ENCONTRADO: " + rol);

        setLocationRelativeTo(null);
        obtenerRegistroTabla();
        tableProduc.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int i = tableProduc.getSelectedRow();
                if (i >= 0) {
                    clave = model.getValueAt(i, 0).toString();
                }
            }
        });

        salirButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Login l = new Login();
                l.setVisible(true);
                setVisible(false);
            }
        });

        buscarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String busqueda = textBuscar.getText().trim().toLowerCase();

                while (model.getRowCount() > 0) {
                    model.removeRow(0);
                }

                mapa = servicio.seleccionarTodo();

                for (Map.Entry<Integer, Producto> entry : mapa.entrySet()) {
                    Producto producto = entry.getValue();
                    if (producto.getCodigo().toLowerCase().contains(busqueda) ||
                            producto.getNombre().toLowerCase().contains(busqueda)) {
                        row[0] = entry.getKey();
                        row[1] = producto.getCodigo();
                        row[2] = producto.getNombre();
                        row[3] = String.format("%.2f", producto.getPrecio());
                        model.addRow(row);
                    }
                }

                if (model.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(null, "No se encontraron productos que coincidan con la búsqueda.");
                }
            }
        });

        añadirButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = tableProduc.getSelectedRow();
                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(null, "Por favor, selecciona un producto para añadir.");
                    return;
                }
                int id = (int) model.getValueAt(selectedRow, 0);
                Producto producto = mapa.get(id);
                if (producto != null) {
                    selectedProducts.add(producto);
                    JOptionPane.showMessageDialog(null, "Producto añadido: " + producto.getNombre());
                }
            }
        });

        mostrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (selectedProducts.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "No has añadido ningún producto.");
                    return;
                }
                StringBuilder message = new StringBuilder("Productos seleccionados:\n");
                double total = 0;
                for (Producto p : selectedProducts) {
                    message.append(p.getCodigo()).append(" - ")
                            .append(p.getNombre()).append(" - ")
                            .append(String.format("%.2f", p.getPrecio())).append("\n");
                    total += p.getPrecio();
                }
                message.append("\nTotal: $").append(String.format("%.2f", total));


                Object[] options = {"Comprar", "Cancelar"};
                int option = JOptionPane.showOptionDialog(null, message.toString(), "Confirmar Compra",
                        JOptionPane.YES_NO_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);
                if (option == JOptionPane.YES_OPTION) {
                    JOptionPane.showMessageDialog(null, "Compra realizada con éxito. Total: $" + String.format("%.2f", total));
                    selectedProducts.clear();
                }
            }
        });

        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = tableProduc.getSelectedRow();
                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(null, "Por favor, selecciona un producto para eliminar.");
                    return;
                }
                int id = (int) model.getValueAt(selectedRow, 0);
                Producto producto = mapa.get(id);
                if (producto != null && selectedProducts.remove(producto)) {
                    JOptionPane.showMessageDialog(null, "Producto eliminado: " + producto.getNombre());
                } else {
                    JOptionPane.showMessageDialog(null, "El producto no está en la lista o no se pudo eliminar.");
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Catalogocliente().setVisible(true));
    }
}