package app.vista.proyectoPoo;

//import taller.taller;

import app.controlador.Servicio;
import app.controlador.Usuario;
import app.modelo.Producto;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Map;

public class Catalogos extends JFrame{
    private JTextField textCodigo;
    private JTextField textPrecio;
    private JButton nuevoButton;
    private JTextField textNombre;
    private JButton actualizarButton;
    private JButton eliminarButton;
    private JTable tableProduc;
    private JPanel catalogos;
    private JButton IMPRIMIRREPORTEButton;
    private JButton salirButton;
    private DefaultTableModel model;
    private JLabel lblBienvenida;
    private JTextField textBuscar;
    private JButton buscarButton;
    private JFrame frame;

    private Object[] columns = {"ID","Codigo","Producto","Precio"};
    private Object[] row = new Object[4];
    private JLabel LblTitulo,LblId,LblPrecio,LblProducto;
    //private JButton nuevoButton,mostrarButton,actualizarButton,eliminarButton;
    private JScrollPane scrollPane = null;
    private Servicio servicio = new Servicio();
    private Map<Integer, Producto> mapa = null;
    private String clave;

    public void obtenerRegistroTabla() {
        model = new DefaultTableModel(){
            private static final long serialVersionUID = 1L;
            @Override
            public boolean isCellEditable(int filas, int columnas)
            {return false;}
        };
        model.setColumnIdentifiers(columns);
        while (model.getRowCount() > 0) {
            model.removeRow(0);
        }
        mapa = servicio.seleccionarTodo();

        for (Map.Entry<Integer, Producto> entry : mapa.entrySet()) {
            row[0] = entry.getKey();
            row[1] = entry.getValue().getCodigo();
            row[2] = entry.getValue().getNombre();
            row[3] = String.format("%.2f", entry.getValue().getPrecio());
            model.addRow(row);
        }
        limpiarCampos();
        tableProduc.setModel(model);
    }
    public void limpiarCampos(){
        textCodigo.setText("");
        textNombre.setText("");
        textPrecio.setText("");
    }

    public Catalogos(){
        setTitle("Catalogos");
        setSize(700, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(catalogos);
        lblBienvenida.setText("Bienvenido, " + Usuario.getUsuario() + " (" + Usuario.getRol() + ")");
        String rol = Usuario.getRol();
        System.out.println("ROL ENCONTRADO: " + rol);

        switch (rol) {
            case "administrador":
                break;

            case "empleado":

                eliminarButton.setEnabled(false);
                break;
            case "cliente":

                Catalogocliente ce =new Catalogocliente();
                ce.setVisible(true);
                break;

            default:
                JOptionPane.showMessageDialog(null, "Rol desconocido. Se limitará el acceso.");
                nuevoButton.setEnabled(false);
                actualizarButton.setEnabled(false);
                eliminarButton.setEnabled(false);
                IMPRIMIRREPORTEButton.setEnabled(false);
        }

        setLocationRelativeTo(null);
        obtenerRegistroTabla();
        tableProduc.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int i=tableProduc.getSelectedRow();
                clave=model.getValueAt(i,0).toString();
                textCodigo.setText(model.getValueAt(i,1).toString());
                textNombre.setText(model.getValueAt(i,2).toString());
                textPrecio.setText(model.getValueAt(i,3).toString());

            }
        });
        nuevoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String codigo = textCodigo.getText().trim();
                String nombre = textNombre.getText().trim();
                String precioStr = textPrecio.getText().trim().replace(",", ".");

                if (codigo.isEmpty() || nombre.isEmpty() || precioStr.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Por favor, completa todos los campos.");
                    return;
                }

                try {
                    double precio = Double.parseDouble(precioStr);
                    if (precio < 0) {
                        JOptionPane.showMessageDialog(null, "El precio no puede ser negativo.");
                        return;
                    }

                    // Check for duplicate code
                    boolean codigoExists = mapa.values().stream()
                            .anyMatch(producto -> producto.getCodigo().equalsIgnoreCase(codigo));
                    if (codigoExists) {
                        JOptionPane.showMessageDialog(null, "El código ya existe. Por favor, usa un código diferente.");
                        return;
                    }

                    servicio.insertar(new Producto(codigo, nombre, precio));
                    obtenerRegistroTabla();
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(null, "Precio inválido.");
                }
            }
        });

        actualizarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = Integer.parseInt(clave);
                String codigo = textCodigo.getText();
                String nombre = textNombre.getText();
                String precioStr = textPrecio.getText().replace(",", ".");
                double precio = Double.parseDouble(precioStr);
                if (precio < 0) {
                    JOptionPane.showMessageDialog(null, "El precio no puede ser negativo.");
                    return;
                }
                servicio.actualizar(new Producto(id, codigo, nombre, precio));
                obtenerRegistroTabla();
            }
        });
        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id=Integer.parseInt(clave);
                servicio.eliminar(id);
                obtenerRegistroTabla();
            }
        });
        IMPRIMIRREPORTEButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    tableProduc.print();
                }catch (Exception e2){
                    System.out.println(e2.getMessage());
                }
            }
        });
        salirButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Login l=new Login();
                l.setVisible(true);
                setVisible(false);

            }
        });

        buscarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String busqueda = textBuscar.getText().trim().toLowerCase();

                while (model.getRowCount() > 0) {
                    model.removeRow(0);
                }

                mapa = servicio.seleccionarTodo();

                for (Map.Entry<Integer, Producto> entry : mapa.entrySet()) {
                    Producto producto = entry.getValue();
                    if (producto.getCodigo().toLowerCase().contains(busqueda) ||
                            producto.getNombre().toLowerCase().contains(busqueda)) {
                        row[0] = entry.getKey();
                        row[1] = producto.getCodigo();
                        row[2] = producto.getNombre();
                        row[3] = String.format("%.2f", producto.getPrecio());
                        model.addRow(row);
                    }
                }

                if (model.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(null, "No se encontraron productos que coincidan con la búsqueda.");
                }

                limpiarCampos();
            }
        });

    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {new Catalogos().setVisible(true);});
    }
}
