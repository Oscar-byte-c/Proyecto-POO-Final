package app.vista.proyectoPoo;

import app.controlador.Usuario;
import app.modelo.UsuarioServicio;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Login extends JFrame {
    private JPanel panelLogin;
    private JTextField txtUsuario;
    private JPasswordField txtContrasena;
    private JButton btnIngresar;
    private JPanel comboRoles;
    private JComboBox comboBox1;

    public Login() {
        setContentPane(panelLogin);
        setTitle("Login - Sistema de Ventas Gym");
        setSize(350, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        comboBox1.removeAllItems();
        comboBox1.addItem("Administrador");
        comboBox1.addItem("Empleado");
        comboBox1.addItem("Cliente");

        btnIngresar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String user = txtUsuario.getText().trim();
                String password = String.valueOf(txtContrasena.getPassword());
                String rolSeleccionado = (String) comboBox1.getSelectedItem();

                UsuarioServicio servicio = new UsuarioServicio();
                if (servicio.validar(user, password, rolSeleccionado)) {
                    Usuario.setUsuario(user);
                    Usuario.setRol(rolSeleccionado.toLowerCase());
                    dispose();


                    if (rolSeleccionado.equalsIgnoreCase("Cliente")) {
                        new Catalogocliente().setVisible(true);
                    } else if (rolSeleccionado.equalsIgnoreCase("Empleado")) {
                        new Catalogos().setVisible(true);
                    } else {
                        new Catalogos().setVisible(true);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos.");
                    txtContrasena.setText("");
                    txtUsuario.setText("");
                }
            }
        });
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Login().setVisible(true));
    }
}
