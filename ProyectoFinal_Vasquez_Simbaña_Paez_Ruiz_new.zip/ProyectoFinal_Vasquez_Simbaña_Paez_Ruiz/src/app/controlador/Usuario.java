package app.controlador;

public class Usuario {
    private static String usuario;
    private static String rol;

    public static String getUsuario() {
        return usuario;
    }

    public static void setUsuario(String u) {
        usuario = u;
    }

    public static String getRol() {
        return rol;
    }

    public static void setRol(String r) {
        rol = r.toLowerCase();
    }


}

