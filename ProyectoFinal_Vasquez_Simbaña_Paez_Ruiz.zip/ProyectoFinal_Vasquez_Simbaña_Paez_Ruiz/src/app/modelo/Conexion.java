package app.modelo;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {
    public Connection conectar() {
        Connection conn = null;
        try {
            Class.forName("org.sqlite.JDBC");
            String url = "jdbc:sqlite:C:/Users/Oscar/Downloads/gym.db";
            conn = DriverManager.getConnection(url);
            System.out.println("Conexión a SQLite exitosa");
        } catch (Exception e) {
            System.out.println("Error al conectar: " + e.getMessage());
        }
        return conn;
    }
}
